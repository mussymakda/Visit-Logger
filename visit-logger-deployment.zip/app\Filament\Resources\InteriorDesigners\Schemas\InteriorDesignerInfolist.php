<?php

namespace App\Filament\Resources\InteriorDesigners\Schemas;

use Filament\Schemas\Schema;

class InteriorDesignerInfolist
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                //
            ]);
    }
}
