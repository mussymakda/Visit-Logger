<?php echo e(\Filament\Support\generate_loading_indicator_html($attributes)); ?>

<?php /**PATH C:\Users\musta\Desktop\Quotation maker\Visit-Logger\vendor\filament\support\resources\views/components/loading-indicator.blade.php ENDPATH**/ ?>