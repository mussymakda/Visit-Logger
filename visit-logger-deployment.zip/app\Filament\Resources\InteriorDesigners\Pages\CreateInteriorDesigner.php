<?php

namespace App\Filament\Resources\InteriorDesigners\Pages;

use App\Filament\Resources\InteriorDesigners\InteriorDesignerResource;
use Filament\Resources\Pages\CreateRecord;

class CreateInteriorDesigner extends CreateRecord
{
    protected static string $resource = InteriorDesignerResource::class;
}
