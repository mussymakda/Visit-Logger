<script>
                    document.addEventListener("DOMContentLoaded", function() {
                        setTimeout(function() {
                            const rememberCheckbox = document.querySelector("input[name=\"remember\"]");
                            if (rememberCheckbox && !rememberCheckbox.checked) {
                                rememberCheckbox.checked = true;
                            }
                        }, 100);
                    });
                </script>