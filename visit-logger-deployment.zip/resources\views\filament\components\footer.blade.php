<div class="text-center text-sm text-gray-500 py-4">
    {{ $text }}
</div>
