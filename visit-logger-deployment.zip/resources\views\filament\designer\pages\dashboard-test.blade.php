<x-filament-panels::page>
    <div class="max-w-md mx-auto space-y-6">
        <h1>Test Dashboard</h1>
        <p>This is a minimal test version.</p>
    </div>
</x-filament-panels::page>
