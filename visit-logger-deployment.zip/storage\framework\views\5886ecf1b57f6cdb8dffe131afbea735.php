<script>
                    document.addEventListener("DOMContentLoaded", function() {
                        setTimeout(function() {
                            const rememberCheckbox = document.querySelector("input[name=\"remember\"]");
                            if (rememberCheckbox && !rememberCheckbox.checked) {
                                rememberCheckbox.checked = true;
                            }
                        }, 100);
                    });
                </script><?php /**PATH C:\Users\musta\Desktop\Quotation maker\Visit-Logger\storage\framework\views/f3f7338ef600dd915d6ad9e0e9057ed3.blade.php ENDPATH**/ ?>